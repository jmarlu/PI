# Ficha inicial

| Campo | Contenido |
|---|---|
| Identificador del alumno | PENDIENTE |
| URL GitHub | PENDIENTE |
| Acceso docente comprobado | PENDIENTE |
| Montaje previsto | Proxmox en VirtualBox; instalación física solo como opción autorizada |
| Recursos conocidos | PENDIENTE |
| Nombre del nodo | PENDIENTE |
| Servicio ASO previsto | PENDIENTE |
| Red de laboratorio | PENDIENTE |
| Riesgos y dudas iniciales | PENDIENTE |

[Volver al indice](../README.md)
