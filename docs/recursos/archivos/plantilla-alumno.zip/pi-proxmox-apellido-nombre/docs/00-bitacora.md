# Bitacora de sesiones

## Sesion 01 - FECHA

- Objetivo: iniciar GitHub y la documentacion Markdown.
- Trabajo realizado: PENDIENTE.
- Decisiones y motivos: PENDIENTE.
- Pruebas y resultados: PENDIENTE.
- Documentos o evidencias: [Ficha inicial](00-ficha-inicial.md).
- Incidencias y solucion o estado pendiente: PENDIENTE.
- Siguiente paso: PENDIENTE.

Anadir una entrada con esta estructura en cada sesion. El historial de
GitHub registra los commits; no hace falta incluir el hash del propio
commit dentro de su entrada de bitacora.

[Volver al indice](../README.md)
