# Memoria tecnica: nodo Proxmox individual

## Resumen y objetivos

PENDIENTE: iniciar en la sesion 1 y completar durante el proyecto.

## Necesidad, alcance y criterios de aceptacion

## Modalidad e inventario

[Inventario](01-inventario-hardware.md)

## Diseno de red

[Diagrama y direccionamiento](02-diagrama-red.md)

## Instalacion y configuracion de Proxmox

[Procedimiento](03-instalacion-proxmox.md)

## Plantilla Linux y despliegue

[Plantilla](04-plantilla-linux.md) y [VMs/LXC](05-vms-lxc.md)

## Servicio ASO

[Instalacion y pruebas](06-servicio-aso.md)

## Automatizacion con Bash y Ansible

[Automatizacion](07-automatizacion.md)

## Copias y restauracion

[Procedimiento y validacion](08-copias-restauracion.md)

## Rendimiento y seguridad

[Resultados](09-rendimiento-seguridad.md)

## Incidencias y decisiones

[Bitacora](00-bitacora.md)

## Presupuesto y sostenibilidad

## Conclusiones

## Fuentes y anexos

[Evidencias](../evidencias/README.md) y [volver al indice](../README.md)
